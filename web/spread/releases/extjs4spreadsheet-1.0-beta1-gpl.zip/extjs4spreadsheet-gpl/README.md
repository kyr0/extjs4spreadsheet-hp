extjs4spreadsheet-gpl
=====================

Open Source (GPLv3) web spreadsheet component built uppon Ext JS 4 GPL.
Commercial version of this component and commercial support is available:
[Project Website](http://www.extjs4spreadsheet.com)
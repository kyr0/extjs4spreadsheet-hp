#!/bin/sh

jsduck src --output docs